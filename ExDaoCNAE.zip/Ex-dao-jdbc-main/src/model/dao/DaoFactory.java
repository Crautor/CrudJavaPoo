package model.dao;

import db.DB;
import model.dao.impl.EixoCNAEJDBC;

public class DaoFactory {

	
	public static EixoCNAE createEixoDao() {
		return new EixoCNAEJDBC(DB.getConnection());
	}
}
