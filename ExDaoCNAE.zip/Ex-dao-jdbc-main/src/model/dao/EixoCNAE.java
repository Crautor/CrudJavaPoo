package model.dao;

import java.util.List;

import model.entities.CNAE;

public interface EixoCNAE {

	void insert(CNAE obj);
	void update(CNAE obj);
	void deleteById(Integer id);
	CNAE findById(Integer id);
	List<CNAE> findAll();
}
